package spring;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import Welcome.WelcomeBean;


@SuppressWarnings("deprecation")
public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Resource r = new ClassPathResource("resource/spconfig.xml");

BeanFactory f = new XmlBeanFactory(r);
Object o= f.getBean("id");
             WelcomeBean wb=(WelcomeBean)o;
             wb.show();
             

	}

}
