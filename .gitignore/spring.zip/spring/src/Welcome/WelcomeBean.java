package Welcome;

public class WelcomeBean {
private DemoBean db;

public void setDb(DemoBean db) {
	this.db = db;
}
public void show() {
	db.m1();
}
}

