package Welcome;

public class DemoBean {
	public void m1() {
		System.out.println("Welocme Saravanan :) Im n the inner bean");
	}
}
